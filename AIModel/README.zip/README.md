# 虚拟机
## Cuda安装
### 参考：https://docs.nvidia.com/cuda/cuda-installation-guide-linux/index.html

![img.png](img.png)
```
lspci | grep -i nvidia
```
查看GPU信息,确保GPU支持CUDA

安装gcc：
```
gcc --version
```
查看gcc版本，如果没有gcc，需要安装gcc
```commandline
sudo apt-get update
sudo apt install build-essential
```

验证系统是否安装了正确的内核头文件和开发包
```commandline
uname -r
```

下载cuda工具包：
前往网站：https://developer.nvidia.com/cuda-downloads?target_os=Linux&target_arch=x86_64&Distribution=Debian&target_version=12&target_type=deb_local
![img_1.png](img_1.png)根据实际情况选择相应型号，选择cuda版本时需要考虑兼容问题，pytorch目前最高支持12.6，可能会与12.8的cuda存在不兼容导致程序出现问题

包管理器安装：根据网页指示安装，此处以Debian为例

安装前操作：
```commandline
sudo apt-get install linux-headers-$(uname -r)
```
启用 contrib 存储库：
```commandline
sudo add-apt-repository contrib
```
删除过期的签名密钥
```commandline
sudo apt-key del 7fa2af80
```
选择安装方法：此处本地安装为例

在文件系统上安装本地存储库：
```commandline
sudo dpkg -i cuda-repo-<distro>-X-Y-local_<version>*_x86_64.deb
```
需要根据系统修改distro，version，x86_64，本例将distro修改为debian，version修改为12.6，x86_64不变

注册临时公共 GPG 密钥：
```commandline
sudo cp /var/cuda-repo-<distro>-X-Y-local/cuda-*-keyring.gpg /usr/share/keyrings/
```
distro修改如上

更新 Apt 存储库缓存
```commandline
sudo apt-get update
```
安装 CUDA
```commandline
sudo apt-get install cuda
```
如果是Debian 10，则可能需要运行：
```commandline
sudo apt-get --allow-releaseinfo-change update
```

安装 CUDA SDK：
```commandline
sudo apt-get -y install cuda
```

重新启动系统：
```commandline
sudo reboot
```
### 安装驱动程序
![img_2.png](img_2.png)
安装完成后使用指令：
```commandline
sudo apt-get install cuda-drivers
```

查看cuda安装情况
```commandline
nvcc --version
```
如果报错，需要永久添加环境变量：
```commandline
sudo nano ~/.bashrc
```
在文件末尾添加
```commandline
export PATH=/usr/local/cuda/bin:$PATH
```

退出编辑后使用：
```commandline
source ~/.bashrc
```
让系统重新加载环境变量

## Python安装
### 安装系统Pyhton
安装python3:
```commandline
sudo apt update
sudo apt-get install python3
```
验证安装：
```commandline
python3 --version
```
添加环境变量
```commandline
which python3   ###得到路径path
```
临时添加环境变量：
```commandline
export PATH=path:$PATH
```
永久添加环境变量:
```commandline
sudo nano ~/.bashrc
```
打开配置文件，然后在最后添加
```commandline
export PATH=$PATH:/path/to/python ### 根据刚才的路径修改
```
退出编辑后使用:
```commandline
source ~/.bashrc
```

### 安装anaconda
参考：https://blog.csdn.net/mieshizhishou/article/details/140269614?ops_request_misc=%257B%2522request%255Fid%2522%253A%252296651e18a3d27d218d3a253ca8d3b333%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=96651e18a3d27d218d3a253ca8d3b333&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_positive~default-1-140269614-null-null.142^v101^pc_search_result_base6&utm_term=linux安装anaconda&spm=1018.2226.3001.4187

在anaconda官网找到相应的版本：https://www.anaconda.com/download/success
![img_3.png](img_3.png)，复制下载链接后使用指令：
```commandline
wget link ### link替换为刚才复制的链接
```
下载安装包后使用指令安装：
```commandline
bash Anaconda3-2023.07-Linux-x86_64.sh
```
进入许可协议查看后可以按q退出查看，然后输入yes同意安装
安装路径建议使用默认路径，点击enter

配置环境变量：
```commandline
sudo nano ~/.bashrc
```
在文件末尾添加
```commandline
export PATH=$HOME/anaconda3/bin:$PATH
```
退出编辑后使用:
```commandline
source ~/.bashrc
```

### 安装pytorch(cuda版本)
参考：https://blog.csdn.net/duan_mo_ran/article/details/125719416?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522cb9bb9dd8cd522367a515c2f0a7c7171%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=cb9bb9dd8cd522367a515c2f0a7c7171&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_positive~default-1-125719416-null-null.142^v101^pc_search_result_base6&utm_term=linux安装pytorch%20gpu版本&spm=1018.2226.3001.4187

使用
```commandline
nvidia-smi
```
查看cuda版本号，然后前往pytorch官网：https://pytorch.org/
![img_4.png](img_4.png)
根据cuda版本下载相应版本的pytorch，复制下载链接后使用指令下载安装包，推荐使用pip安装
测试是否安装成功：
```commandline
python  ### 先进入python
import torch
print(torch.cuda.is_available())
```
如果之前虚拟环境利用cpu的pytorch，记得需要先删除。不然一直装不好。

## 模型下载
首先把需要的python环境编写进入requirements.txt文件，然后在虚拟python环境中执行：
```commandline
pip install -r requirements.txt
```
安装所有需要的环境，修改model_download.py文件中的模型名称和下载路径，保存后执行py文件即可下载安装模型

## 模型微调
### lora微调
参考：https://github.com/datawhalechina/self-llm/blob/master/models/DeepSeek/04-DeepSeek-7B-chat%20Lora%20微调.md

主要修改部分在于process_func函数，需要根据自定数据集来修改example中的Key和values
修改args变量中的输出路径，微调后可以测试模型的效果，如果效果不佳可以修改精度，lora_config等参数

### 全参微调
主要问题在于使用deepspeed，参考full-finetune文件

## 模型测试
参考test.py, test7B.py

## ollama部署
下载地址：https://ollama.com/

参考：https://blog.csdn.net/hooksten/article/details/145418987?ops_request_misc=&request_id=&biz_id=102&utm_term=ollama%E4%B8%8B%E8%BD%BD%E5%88%B0linux%E6%8C%87%E5%AE%9A%E6%96%87%E4%BB%B6%E5%A4%B9%E4%B8%8B&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduweb~default-1-145418987.142^v101^pc_search_result_base6&spm=1018.2226.3001.4187 可以修改ollama模型部署到本地的路径（可选）

**不要修改/home下的所有权限，会导致ssh权限过于宽松，从而导致服务器拒绝ssh连接**

解决办法：如果是Google cloud的虚拟机，则点击修改虚拟机实例信息，在远程访问处允许连接到串行端口，然后使用串行端口连接服务器来恢复/home下的权限

![img_5.png](img_5.png)
![img_6.png](img_6.png)
![img_7.png](img_7.png)

## 使用ollama导入lora微调的模型
参考：https://blog.csdn.net/spiderwower/article/details/138755776?ops_request_misc=&request_id=&biz_id=102&utm_term=ollama怎么部署微调模型&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduweb~default-0-138755776.142^v101^pc_search_result_base6&spm=1018.2226.3001.4187

使用checkpoint_to_lora.py文件将训练的checkpoint保存为lora，再使用merge.py文件将lora模型和原始模型进行合并，记得修改两个py文件中的路径信息

量化模型：将合并后的模型（仍然有很多safetensors）合并为一个bin，需要使用llama.cpp
```commandline
#1.下载llama.cpp源码并进入到该目录
git clone https://github.com/ggerganov/llama.cpp.git
cd llama.cpp
#2.用anaconda创建一个虚拟环境
conda create -n llama python=3.10
conda init bash
source /root/.bashrc
#3.激活环境
conda activate llama
#4.安装llama.cpp项目依赖
pip install -r requirements.txt
#5.执行转换脚本
python convert_hf_to_gguf.py /path/to/merged_model --outtype f16 --outfile /path/to/convert_model/convert.bin
```
对llama.cpp进行编译

参考：https://blog.csdn.net/spiderwower/article/details/138506271

安装cmake:参考（https://blog.csdn.net/qq_42598221/article/details/121952160?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522171499948616800188549161%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=171499948616800188549161&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_click~default-1-121952160-null-null.142%5Ev100%5Epc_search_result_base5&utm_term=windows%20cmake%E5%AE%89%E8%A3%85&spm=1018.2226.3001.4187）

前往官网：https://cmake.org/ 找到相应的版本：![img_8.png](img_8.png)
复制下载链接后使用指令：
```commandline
wget https://github.com/Kitware/CMake/releases/download/v4.0.0-rc2/cmake-4.0.0-rc2-linux-x86_64.sh
```
下载安装包后使用指令安装：
```commandline
bash cmake-4.0.0-rc2-linux-x86_64.sh
```
检测是否安装成功
```commandline
cmake --version
```
检查c++编译器
```commandline
g++ --version
```
开始编译：
```commandline
# 进入到llm/llama.cpp目录
cd llm/llama.cpp
 
#创建build文件夹
mkdir build
 
#进入build
cd build
 
# 构建
cmake ..
cmake --build . --config Release
```
linux上编译完成后没有quantization.exe文件，对应的文件是：llama.cpp/build/bin/llama-quantize
使用该文件量化：
```commandline
llama.cpp/build/bin/llama-quantize /path/to/convert_model/converted.bin /path/to/quantized.bin q4_0
```
官方文档提供了多种量化格式，常用的就是q4_0。

![img_9.png](img_9.png)
量化完成后会获得一个quantized.bin文件，之前的converted.bin可以删除（如果不需要其他量化的话）

创建Modelfile文件，其内容如下：
```commandline
FROM D:\huggingface\itpossible\quantized.bin
TEMPLATE "[INST] {{ .Prompt }} [/INST]"
```
保存文件后执行：
```commandline
ollama create model_name -f /path/to/Modelfile
ollama run model_name
```
